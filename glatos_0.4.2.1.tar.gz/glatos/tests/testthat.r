library(testthat)
library(glatos)

test_check("glatos")
